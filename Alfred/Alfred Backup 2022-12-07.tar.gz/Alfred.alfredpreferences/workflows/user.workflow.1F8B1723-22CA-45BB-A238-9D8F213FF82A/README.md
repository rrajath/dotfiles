## v2
* cache token
* add cm-update-token to trigger update token manually

## v1 init version