# encoding: utf-8

import os, sys, json

def messages2Items(wf, messages):
    count = 20
    for message in messages:
        count -= 1
        if count > 0:
            message2Item(wf, message)

def message2Item(wf, message):
    query = None
    if len(sys.argv) > 1:
        query = sys.argv[1]

    wf.add_item(message['Content'], message['CreatedOn'], arg=query)


def contacts2Items(wf, contacts, query=None):
    contacts = wf.filter(query, contacts, keyForContact)
    for contact in contacts:
        contact2Item(wf, contact)

def keyForContact(contact):
    return '{} {}'.format(contact['email'], contact['display_name'])

def contact2Item(wf, contact):
    login = contact['email'].split('@')[0]
    arg = {
        'login': login,
        'name': contact['display_name'],
        'email': contact['email'],
        'profileId': contact['id'],
    }
    wf.add_item(
        '{} - @{}'.format(contact['display_name'], contact['email']), 'Open in Chime', valid=True, arg=json.dumps(arg), copytext=contact['email'])

def conversations2Items(wf, conversations, query=None):
    conversations = wf.filter(query, conversations, keyForConversation)
    for conversation in conversations:
        conversation2Item(wf, conversation)

def keyForConversation(conversation):
    arg = buildConverstionArg(conversation)
    return '{} {}'.format(arg['login'], arg['name'])

def buildConverstionArg(conversation):
    members = conversation['Members']
    login = os.environ['USER']

    for m in members:
        if login not in m['Email']:
            target = m
            break

    email = target['Email']
    targetLogin = email[0:email.find('@')]

    arg = {
        'login': targetLogin,
        'name': target['DisplayName'],
        'email': target['Email'],
        'profileId': target['ProfileId'],
        'conversationId': conversation['ConversationId']
    }
    return arg


def conversation2Item(wf, conversation):
    members = conversation['Members']
    login = os.environ['USER']

    for m in members:
        if login not in m['Email']:
            target = m
            break

    email = target['Email']
    targetLogin = email[0:email.find('@')]

    arg = {
        'login': targetLogin,
        'name': target['DisplayName'],
        'email': target['Email'],
        'profileId': target['ProfileId'],
        'conversationId': conversation['ConversationId']
    }
    wf.add_item(
        '{} - @{}'.format(target['DisplayName'], targetLogin), 'Open in Chime', valid=True, arg=json.dumps(arg), copytext=targetLogin)
