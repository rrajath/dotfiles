# encoding: utf-8
from workflow import web
import json  

class ChimeApi:
    CHIME_HOST = 'https://api.express.ue1.app.chime.aws/'

    def __init__(self, token):
        self.token = token

    # "{"id":"","email":"","display_name":"","full_name":"","presence_channel":"","profile_channel":"","personal_phone_number":null,"provisioned_phone_number":null,"work_talk_account_id":""}"
    def getContacts(self):
        url = 'bazl/contacts/'
        return self._getJson(url)

    def getRecentChats(self):
        return self.getChats('recent')

    def getFavoriteChats(self):
        return self.getChats('favorites')

    def getChats(self, type):
        url = "msg/conversations/?%s=true" % (type)
        r = self._getJson(url)
        return r

    # {"Messages": [{}]}
    def getIndividualConversation(self, conversationId):
        url = "msg/conversations/" + conversationId + "/messages/"
        return self._getJson(url)


    # {"Presences":[{"Availability":2,"ProfileId":"","Revision":1566970157484},{"Availability":1,"ProfileId":"","Revision":1566970157484},{"Availability":5,"ProfileId":"","Revision":1566970157484}}]
    # 1: offline 2:online 3:outing 4:busy 5:mobile 6:locked
    def getPresences(self, profileIds):
        profileIdsStr = ','.join(x for x in profileIds)
        url = "copr/presence?profile-ids=" + profileIdsStr
        r = _getJson(url)
        return r

    def sendMessageToIndividual(self, conversationId, message):
        url = "msg/conversations/" + conversationId + "/messages/"
        message = {
            'ConversationID': conversationId,
            'Content': message
        }
        return self._post(url, json.dumps(message))

    def _post(self, url, data):
        headers = {
            'X-Chime-Auth-Token': "_aws_wt_session=%s" % (self.token),
        }
        r = web.post(self.CHIME_HOST + url, data=data, headers=headers)
        if r.status_code != 200:
            return False
        return True

    def _getJson(self, url):
        headers = {
            'X-Chime-Auth-Token': "_aws_wt_session=%s" % (self.token),
        }
        r = web.get(self.CHIME_HOST + url, headers=headers)
        if r.status_code != 200:
            return False
        data = r.json()
        return data
