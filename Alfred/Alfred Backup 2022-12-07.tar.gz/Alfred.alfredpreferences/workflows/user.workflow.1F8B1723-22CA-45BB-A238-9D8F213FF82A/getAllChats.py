# encoding: utf-8

import sys, json, adaptor, utils 
from workflow import Workflow3, ICON_WEB, web
from chime import ChimeApi
from metrics import sendMetricAysnc


def main(wf):
    query = None

    if len(sys.argv) > 1:
        query = sys.argv[1]

    token = utils.getChimeToken(wf)
    if token == "False":
        return

    chimeApi = ChimeApi(token)
    chats = wf.cached_data(
        'getFavoriteChats', chimeApi.getFavoriteChats, max_age=86400)

    if chats != False:
        if 'Conversations' in chats:
            adaptor.conversations2Items(wf, chats['Conversations'], query)

    chats = wf.cached_data('getRecentChats', chimeApi.getRecentChats, max_age=7200)
    if chats != False:
        if 'Conversations' in chats:
            adaptor.conversations2Items(wf, chats['Conversations'], query)

    if query != None:
        arg = {
            'login': query,
            'email': query + "@amazon.com",
        }
        item = wf.add_item("Open a new chat with \"{}@amazon.com\"".format(query),
        'Open in Chime', arg=json.dumps(arg), valid=True)
        item.add_modifier('cmd', 'Not supported sending messages directly', valid=False)


    wf.send_feedback()
    sendMetricAysnc('getAllChats', wf.alfred_env['version'])


if __name__ == u"__main__":
    wf = Workflow3()
    sys.exit(wf.run(main))
