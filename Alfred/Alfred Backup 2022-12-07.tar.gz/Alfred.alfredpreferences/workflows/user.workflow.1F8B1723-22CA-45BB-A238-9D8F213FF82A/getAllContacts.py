# encoding: utf-8

import sys, json, adaptor, utils
from workflow import Workflow3, ICON_WEB, web
from chime import ChimeApi
from metrics import sendMetricAysnc


def main(wf):
    query = None

    if len(sys.argv) > 1:
        query = sys.argv[1]

    token = utils.getChimeToken(wf)
    if token == "False":
        return
    chimeApi = ChimeApi(token)
    contacts = wf.cached_data(
        'getContacts', chimeApi.getContacts, max_age=86400)
    if contacts != False:
        adaptor.contacts2Items(wf, contacts, query)

    if query:
        arg = {
            'login': query,
            'email': query + "@amazon.com",
        }
        item = wf.add_item("Open a new chat with \"{}@amazon.com\"".format(query),
        'Open in Chime', arg=json.dumps(arg), valid=True)

    wf.send_feedback()
    sendMetricAysnc('getAllContacts', wf.alfred_env['version'])


if __name__ == u"__main__":
    wf = Workflow3()
    sys.exit(wf.run(main))
