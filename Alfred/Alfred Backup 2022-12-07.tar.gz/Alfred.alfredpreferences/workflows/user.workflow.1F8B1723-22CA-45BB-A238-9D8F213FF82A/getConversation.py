# encoding: utf-8

import sys, json, os, adaptor, utils
from workflow import Workflow3, ICON_WEB, web
from chime import ChimeApi
from metrics import sendMetricAysnc

def main(wf):
    token = utils.getChimeToken(wf)
    if token == "False":
        return
    chimeApi = ChimeApi(token)
    conversationInfo = utils.getConversationInfoFromEnv()
    r = chimeApi.getIndividualConversation(conversationInfo['conversationId'])

    if r == False:
        return
    
    adaptor.messages2Items(wf, r['Messages'])

    wf.send_feedback()
    sendMetricAysnc('getConversation', wf.alfred_env['version'])
    

if __name__ == u"__main__":
    wf = Workflow3()
    sys.exit(wf.run(main))

