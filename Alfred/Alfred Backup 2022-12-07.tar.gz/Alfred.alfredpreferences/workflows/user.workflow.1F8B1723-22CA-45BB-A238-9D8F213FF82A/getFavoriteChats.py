# encoding: utf-8

import sys, utils
from workflow import Workflow3, ICON_WEB, web
from chime import ChimeApi
import adaptor
from metrics import sendMetricAysnc

def main(wf):
    token = utils.getChimeToken(wf)
    if token == "False":
        return
    chimeApi = ChimeApi(token)
    chats = wf.cached_data('getFavoriteChats', chimeApi.getFavoriteChats, max_age=86400)
    if not chats or 'Conversations' not in chats:
        wf.add_item('No items')
    else:
        adaptor.conversations2Items(wf, conversations=chats['Conversations'])

    wf.send_feedback()
    sendMetricAysnc('getFavoriteChats', wf.alfred_env['version'])


if __name__ == u"__main__":
    wf = Workflow3()
    sys.exit(wf.run(main))

