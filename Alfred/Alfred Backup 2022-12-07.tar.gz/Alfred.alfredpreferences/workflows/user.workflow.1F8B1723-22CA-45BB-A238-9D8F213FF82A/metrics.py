# encoding: utf-8

# this is for recoarding metrics. Not collect privacy data
# https://cuichenh.aka.corp.amazon.com:8443/index.html

from workflow import web, background
import sys, json, os, ssl


if __name__ == u"__main__":
    # program, action, version
    ssl._create_default_https_context = ssl._create_unverified_context
    print(web.post('https://cuichenh.aka.corp.amazon.com:8443/logs', data=sys.argv[1], 
    headers={'content-type': ' application/json'}))
    

def sendMetricAysnc(action, version=1):
    log = {
        'program': 'ChimeWorkflow',
        'action': action,
        'version': version
    }
    background.run_in_background('sendMetric', ['/usr/bin/python', 'metrics.py', json.dumps(log)])
    