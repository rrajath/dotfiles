# encoding: utf-8

import sys, json, adaptor, utils
from workflow import util
from chime import ChimeApi
import adaptor
from metrics import sendMetricAysnc

# conversationId, login, name
conversationInfo = utils.getConversationInfoFromEnv()
if not conversationInfo:
    print('conversationInfo is not set')
    exit(0)

util.run_applescript('''
activate application "Amazon Chime"
set email to "{}@amazon.com"
set the clipboard to email
tell application "System Events" to tell process "Amazon Chime"
    keystroke "n" using {{shift down, command down}}
    delay 0.5
    key code 51 using {{command down}}
    keystroke "v" using {{command down}}
    delay 1.5
    keystroke tab
    keystroke return
    delay 0.5
    keystroke return
    keystroke return
end tell
''' .format(conversationInfo['login']))
sendMetricAysnc('openConversation')

