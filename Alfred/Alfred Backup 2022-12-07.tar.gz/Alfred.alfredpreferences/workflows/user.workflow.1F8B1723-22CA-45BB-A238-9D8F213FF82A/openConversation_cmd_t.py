# encoding: utf-8

import sys, json, adaptor, utils, os
from workflow import util, Workflow3
from chime import ChimeApi
import adaptor
from metrics import sendMetricAysnc

def main(wf):
    # conversationId, login, name
    conversationInfo = utils.getConversationInfoFromEnv()
    if not conversationInfo:
        print('conversationInfo is not set')
        return

    delayTime = os.getenv('open_chat_delay_time')


    util.run_applescript('''
    activate application "Amazon Chime"
    set email to "{}@amazon.com"
    set the clipboard to email
    tell application "System Events" to tell process "Amazon Chime"
        keystroke "t" using {{command down}}
        delay 0.5
        key code 51 using {{command down}}
        keystroke "v" using {{command down}}
        delay {}
        keystroke tab
        keystroke return
        delay 0.5
        keystroke return
    end tell
    ''' .format(conversationInfo['login'], delayTime))
    sendMetricAysnc('openConversation', wf.alfred_env['version'])
    

if __name__ == u"__main__":
    wf = Workflow3()
    sys.exit(wf.run(main))



