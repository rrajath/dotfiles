# encoding: utf-8

import sys, json, os, adaptor, utils
from workflow import Workflow3, ICON_WEB, web, util
from chime import ChimeApi
from metrics import sendMetricAysnc

def main(wf):
    query = None

    if len(sys.argv) > 1:
        query = sys.argv[1]

    util.run_applescript('''
    activate application "Amazon Chime"
    set the clipboard to "{}"
    tell application "System Events" to tell process "Amazon Chime"
        keystroke "f" using {{command down}}
        key code 51 using {{command down}}
        keystroke "v" using {{command down}}
        keystroke return
    end tell
    '''.format(query))
    sendMetricAysnc('searchInChime', wf.alfred_env['version'])
    

if __name__ == u"__main__":
    wf = Workflow3()
    sys.exit(wf.run(main))

