# encoding: utf-8

import os, sys, json, utils
from workflow import Workflow3
from chime import ChimeApi
from metrics import sendMetricAysnc

def main(wf):
    # conversationId, login, name, email
    conversationInfo = utils.getConversationInfoFromEnv()
    token = utils.getChimeToken(wf)
    if token == "False":
        return
    chimeApi = ChimeApi(token)
    if chimeApi.sendMessageToIndividual(conversationInfo['conversationId'], sys.argv[1]):
        print('Successful!')
    else:
        print('Sorry, failed')

    sendMetricAysnc('sendMessages', wf.alfred_env['version'])
    

if __name__ == u"__main__":
    wf = Workflow3()
    sys.exit(wf.run(main))