# encoding: utf-8

import utils
import sys
from workflow import Workflow3, ICON_WEB, web
from chime import ChimeApi
from metrics import sendMetricAysnc


def main(wf):
   token = utils.getTokenFromKeyChain(wf)
   sendMetricAysnc('setToken', wf.alfred_env['version'])
   if token == "False":
       print('Failed. Please try again.')
   else:
       print('Successfully!')

if __name__ == u"__main__":
    wf = Workflow3()
    sys.exit(wf.run(main))
