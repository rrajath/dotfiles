# encoding: utf-8

import os, json
from chime import ChimeApi

def getChimeToken(wf):
    return wf.cached_data('session_token', lambda :getTokenFromKeyChain(wf), max_age=30*86400)
    
def getTokenFromKeyChain(wf):
    try:
        token = wf.get_password('session_token', 'Amazon Chime Session Token')
    except BaseException:
        wf.add_item('Please grant permisstion to access the chime token')
        wf.send_feedback()
        return "False"
    else:
        return token


def getConversationInfoFromEnv():
    conversationJson = os.getenv('conversationJson')
    if not len(conversationJson):
        return "False"
    # conversationId, login, name, email
    return json.loads(conversationJson)